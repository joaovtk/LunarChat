package org.github.lunar.lunarchat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LunarchatApplication {

	public static void main(String[] args) {
		SpringApplication.run(LunarchatApplication.class, args);
	}

}
