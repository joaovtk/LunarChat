package org.github.lunar.lunarchat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LunarchatApplicationTests {

	@Test
	void contextLoads() {
	}

}
